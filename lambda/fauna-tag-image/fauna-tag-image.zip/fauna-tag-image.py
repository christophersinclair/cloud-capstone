
def tag_image(event, context):
    return "Hello, world!"